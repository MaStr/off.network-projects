[Noita][demo]
==================

[![Build Status][ci-badge]][ci]

[Jekyll][jekyll] theme built with [Foundation][foundation]. Check out the [demo site][demo] with description and tests.

[ci]: https://travis-ci.org/penibelst/jekyll-noita
[ci-badge]: https://travis-ci.org/penibelst/jekyll-noita.svg?branch=gh-pages
[demo]: http://noita.penibelst.de/
[foundation]: http://foundation.zurb.com/
[jekyll]: http://jekyllrb.com/
