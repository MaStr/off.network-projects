---
title: Coconut Water
layout: post
description: "When drinking coconut water with jelly, why do some pieces of jelly float, while some semi-sink and others completely sink?"
robots: none
---

I gain most of my common knowledge from Reddit. Feel bad for whoever paid $ 7000 for this. Got 2 free Starbucks drinks on my tab! Waiting to redeem them at the most opportune moment. 4 hours left till the tax return deadline. Time to file my Canadian taxes. The last time Starbucks offered me a free drink, I went to the store with a banana and a Kitkat bar, and asked them to make me a smoothie. Web development: where supreme competence meets supreme incompetence.

Raps win. Rob Ford gone. This is clearly the best day of the week. What a great night for sports. Wow, how did Colorado Avalanche lose this? They had the lead 4 times in this game. Ridiculously good weather in Toronto today. I’ve spent more hours outdoors (26) than I’ve spent indoors (15) this weekend. And that includes sleeping. Body is feeling it. Spotted: someone is at the gym lifting weights in a Canadian winter jacket with the hood up. Context switching when programming is a PITA. I just came back to some code I was working on a few weeks ago and I’m lost.

God damnit, why is Rob Ford in the news everyday? Sunnyvale weather has hit Toronto. Hallelujah! How good does it feel when you suddenly realize on Sunday night that you have Monday off? I actually feel pleased my national side is being humiliated. That’s disengagement.


*[PITA]: Pain in the ass
