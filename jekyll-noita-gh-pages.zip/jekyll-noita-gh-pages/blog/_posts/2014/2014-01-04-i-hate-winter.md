---
title: "I Hate Winter"
layout: post
description: "You think Istanbul and Lint hurt your feelings? You clearly don’t wear a fitbit. Tells me how out of shape I really am."
robots: none
---

I was in the rear-most seat on my flight to LAX and it was one of those planes where the engine is on the tail. Eardrum has had better days. Great weather as always. And now I’m off to Iceland! Just dropping parents off. Why didn’t you stop me, you tool? I remember very little about it.

The four stages of Morse:

1. I don’t know Morse.
2. I know enough Morse to get by.
3. I *know* Morse.
4. Fuck Morse.

Checking out a new Vietnamese restaurant. I gotta go back to Jasper and Banff next summer. My condolences. I hate winter. You think Istanbul and Lint hurt your feelings? You clearly don’t wear a fitbit. Tells me how out of shape I really am.

You can now download the theme as [zip](https://github.com/penibelst/jekyll-noita/archive/gh-pages.zip). Thanks to Eric. We’re talking about Jekyll tomorrow in Johannesburg. Please join in the discussion. You’re welcome.

Working from a coffee shop with two others. View my two latest photos on Flickr. Another sexy layout up for Foundation. This one recreates the side menu used on the site. Go forth and download. Not at all. Sorry dude. Great place! I go there often.

Very often I find myself needing a font weight in between the available font weights. I’m a very particular man. I’m surprised you didn’t tweet: “I’m Grove, you may have heard about my combo handler”. That was the best line from conference.

## Christmasy color scheme

Christmas is coming, so I’m using a Christmasy color scheme in *Sublime Text*. 24 years of Tendulkar about to come to a close. I’m not gonna get much sleep over the next five days. I would love to sign off his Test career with a vintage century.

The new app is gorgeous! Can’t sleep. So nervous. Waiting for one of those moments in life you know you’re going to remember. Great anecdote Harsha! Hank you for the memories.

So tired of clicking a link on my phone, and being directed to an app download page for the website. Stop breaking the web. I really like Wordpress! Well, unless someone used Foundation as a base and wrote a theme on top of that. That’s what I would expect people to publish.

Toronto has become the laughingstock of the world thanks to our idiotic mayor. I haven’t been overly vocal about it, but it’s a no-brainer to me. He was imitating a drunk driver at city council yesterday. Yeah, I’m in the same boat. *Daily Show* parody of Rob Ford might be best yet.

Hey, what’s the best way to get [Foundation](http://foundation.zurb.com/) on the front-end frameworks list? Watching Jeremy Jahns reviews is the best way to procrastinate. Hanging out in a hangout.

## Big Jekyll hoodies

Well, that escalated quickly. “Better to prevent and prepare rather than repent and repair.” Going down to 19 °F tomorrow in Toronto! That’s &minus;9 °C, and I can’t find my winter jacket. Hope these big Jekyll hoodies work.

> The distance from my brain to my blog has shrunk, and, in the end, I think that will make me a better author.
>
> *--- [Tom Preston-Werner](http://tom.preston-werner.com/2008/11/17/blogging-like-a-hacker.html), cofounder of Github*

You must *really* enjoy round the world trips, writing books and hacking on frameworks. *Interface Weekly*, now with more bad puns and a slightly tweaked format. Let me know if you prefer this or not. Pretty proud that Ontario will soon become the first province in North America to ban coal-fired power generation.

I’m really digging this series. I hope you get Part 3 up soon! Diego asks: “Do you have handy the link with the playground for browser events?” Nicolas answers: “I’m looking forward to the day we can use native components to do our job, because *this* (waves hands in all directions) is bullshit.”

Come over next week and you can help us decorate ours. Yes, let’s do this next Friday. I wanted help in assembling it anyway.

*[LAX]: Los Angeles International Airport
