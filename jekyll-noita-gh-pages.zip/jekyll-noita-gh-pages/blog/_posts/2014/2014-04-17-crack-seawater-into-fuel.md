---
title: "Crack Seawater Into Fuel"
layout: post
description: "The loader is more shady than a palm tree on a beach. I’m mad scared of South Africa."
robots: none
---

You gotta open with Hussey or come down. [The Emerging Global Web][1] presentation is eye-opening. Uh, the Navy found a way to affordably crack seawater into fuel? This seems like “a big deal”. In all seriousness though, the stuff sounds awesome. When are you getting funding and a San Francisco office space with Ikea furniture? I’m a Core Data newbie. What’s the best way for me to pick it up in your opinion?

> Foundation is truly mobile first, natively built on Sass, optimized for responsive, has a tight community, and has one sharp Yeti.
>
> *--- [Bryan Zmijewski][2], chief instigator of Zurb*

Yahoo may be interested. Message me if you need. One of my favorite debugging tricks: enough sleep. Pro tip: never call yourself an expert. That’s a word that only means something coming from others. Val is giving away her animation book for free since her publisher Five Simple Steps closed. I got your back, don’t worry. You mean “determination”, right? I’m a noob, I don’t even a year’s worth of experience in it. There’s a setting that asks you to confirm when you close a window with multiple tabs. World’s best chasers:

* Leopards
* Soda water
* Virat Kohli

Make it small. Make it dead simple. What’s the deal with all these chipmunk songs at Starbucks? The loader is more shady than a palm tree on a beach. I probably missed most of my classes in my final year of university. Thanks man. Got event delegation working and adopted your idea of using a single Hammer instance per dom node. Looks like I’m only productive after 2&nbsp;AM. Was funny originally, but is just annoying now. Why don’t they teach us how to file taxes in high school? I’m mad scared of South Africa.

[1]: http://www.slideshare.net/yiibu/the-emerging-global-web
[2]: https://twitter.com/bryanzmijewski/status/457181582856429569
